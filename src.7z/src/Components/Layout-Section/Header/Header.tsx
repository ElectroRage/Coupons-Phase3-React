import "./Header.css";
import AppBar from '@mui/material/AppBar';
export function Header(): JSX.Element {
    return (
        <div className="Header">
            <AppBar position = "static">
            </AppBar>
        </div>
    );
}
