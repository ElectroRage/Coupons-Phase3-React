import "./HomePage.css";

export function HomePage(): JSX.Element {
    return (
        <div className="HomePage">
			
        </div>
    );
}
