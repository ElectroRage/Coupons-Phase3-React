import "./AdminPage.css";
import {AllCompanysComp} from "../AllCompanysComp/AllCompanysComp";

export function AdminPage(): JSX.Element {
    return (
        <div className="AdminPage">
            <AllCompanysComp/>
        </div>
    );
}
