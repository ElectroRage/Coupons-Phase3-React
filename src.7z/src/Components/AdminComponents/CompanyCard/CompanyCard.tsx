import "./CompanyCard.css";
import {Company} from "../../../Models/Company";

interface CompanyCardProps {
    company: Company;
}


export function CompanyCard(props: CompanyCardProps): JSX.Element {
    return (
        <div className="CompanyCard">
            <p><strong>ID: </strong>{props.company.id}</p>
            <p><strong>Company Name: </strong>{props.company.name}</p>
            <p><strong>Email: </strong>{props.company.email}</p>
        </div>
    );
}
